import { useState, useEffect } from 'react';
import { Pickaxe, Wallet, Loader2, Coins, Zap, CheckCircle2, AlertCircle, Gift, Clock } from 'lucide-react';
import { motion } from 'motion/react';

const COINS_PER_HOUR = 500;
const COINS_PER_SECOND = COINS_PER_HOUR / 3600;
const MIN_WITHDRAW = 100;
const DAILY_BONUS_AMOUNT = 700;
const BONUS_COOLDOWN_MS = 24 * 60 * 60 * 1000;

export default function App() {
  const [balance, setBalance] = useState<number>(() => {
    const saved = localStorage.getItem('pepe_balance');
    return saved ? parseFloat(saved) : 0;
  });
  
  const [lastClaimedTime, setLastClaimedTime] = useState<number | null>(() => {
    const saved = localStorage.getItem('pepe_last_bonus');
    return saved ? parseInt(saved, 10) : null;
  });
  const [bonusMessage, setBonusMessage] = useState('');
  const [bonusStatus, setBonusStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const [isMining, setIsMining] = useState<boolean>(false);
  const [faucetPayEmail, setFaucetPayEmail] = useState('');
  const [withdrawStatus, setWithdrawStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [withdrawMessage, setWithdrawMessage] = useState('');

  // Save balance to local storage whenever it changes
  useEffect(() => {
    localStorage.setItem('pepe_balance', balance.toString());
  }, [balance]);

  // Mining loop function
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (isMining) {
      interval = setInterval(() => {
        // Update 10 times a second for smooth animation
        setBalance(prev => prev + (COINS_PER_SECOND / 10));
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isMining]);

  const handleClaimBonus = () => {
    const now = Date.now();
    if (lastClaimedTime && now - lastClaimedTime < BONUS_COOLDOWN_MS) {
      const timeLeft = BONUS_COOLDOWN_MS - (now - lastClaimedTime);
      const hours = Math.floor(timeLeft / (1000 * 60 * 60));
      const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
      setBonusStatus('error');
      setBonusMessage(`Please wait ${hours}h ${minutes}m for the next bonus.`);
      setTimeout(() => setBonusMessage(''), 4000);
      return;
    }

    setBalance(prev => prev + DAILY_BONUS_AMOUNT);
    setLastClaimedTime(now);
    localStorage.setItem('pepe_last_bonus', now.toString());
    setBonusStatus('success');
    setBonusMessage(`Successfully claimed ${DAILY_BONUS_AMOUNT} PEPE!`);
    setTimeout(() => setBonusMessage(''), 4000);
  };

  const handleWithdraw = async () => {
    setWithdrawStatus('idle');
    setWithdrawMessage('');

    if (balance < MIN_WITHDRAW) {
      setWithdrawStatus('error');
      setWithdrawMessage(`Minimum withdrawal is ${MIN_WITHDRAW} PEPE.`);
      return;
    }

    if (!faucetPayEmail || !faucetPayEmail.includes('@')) {
      setWithdrawStatus('error');
      setWithdrawMessage('Please enter a valid FaucetPay email address.');
      return;
    }

    setWithdrawStatus('loading');

    try {
      const response = await fetch('/api/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: MIN_WITHDRAW,
          to: faucetPayEmail,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setBalance(prev => prev - MIN_WITHDRAW);
        setWithdrawStatus('success');
        setWithdrawMessage(data.message || `Successfully withdrawn ${MIN_WITHDRAW} PEPE!`);
        setFaucetPayEmail('');
      } else {
        setWithdrawStatus('error');
        setWithdrawMessage(data.message || 'Withdrawal failed. Please try again.');
      }
    } catch (err) {
      setWithdrawStatus('error');
      setWithdrawMessage('Network error. Failed to reach the server.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col items-center py-10 px-4">
      {/* Header */}
      <header className="w-full max-w-2xl flex justify-between items-center bg-slate-900 p-4 rounded-2xl border border-slate-800 shadow-xl mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-xl shadow-[0_0_15px_rgba(34,197,94,0.5)]">
            🐸
          </div>
          <h1 className="text-xl font-bold bg-gradient-to-r from-green-400 to-green-600 bg-clip-text text-transparent">
            PepeMiner
          </h1>
        </div>
        <div className="flex flex-col items-end">
          <div className="text-xs text-slate-400 font-medium uppercase tracking-wider">Your Balance</div>
          <div className="text-2xl font-mono font-bold text-green-400 flex items-center gap-2">
            {balance.toFixed(4)} <span className="text-sm">PEPE</span>
          </div>
        </div>
      </header>

      <main className="w-full max-w-2xl flex flex-col gap-6">
        {/* Daily Bonus Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex flex-col items-center sm:items-start text-center sm:text-left">
            <h2 className="text-xl font-bold flex items-center gap-2 text-yellow-400">
              <Gift className="w-6 h-6" /> Daily Bonus
            </h2>
            <p className="text-sm text-slate-400 mt-1">Claim {DAILY_BONUS_AMOUNT} PEPE every 24 hours</p>
            {bonusMessage && (
              <div className={`mt-2 text-sm flex items-center gap-1 ${bonusStatus === 'success' ? 'text-green-400' : 'text-red-400'}`}>
                {bonusStatus === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                {bonusMessage}
              </div>
            )}
          </div>
          <button 
            onClick={handleClaimBonus}
            className="px-6 py-3 bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-bold rounded-xl shadow-[0_0_15px_rgba(234,179,8,0.3)] transition-all flex items-center gap-2"
          >
            Claim Bonus
          </button>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Mining Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col items-center justify-center relative overflow-hidden">
          <div className="absolute top-4 left-4 flex items-center gap-2 text-xs font-semibold px-3 py-1 bg-slate-800 rounded-full text-green-400">
            <Zap className="w-3 h-3" />
            {COINS_PER_HOUR} / Hour
          </div>

          <motion.div
            animate={isMining ? {
              rotate: [-10, 10, -10],
              y: [0, -10, 0]
            } : {}}
            transition={{
              repeat: Infinity,
              duration: 0.5,
              ease: "easeInOut"
            }}
            className="w-32 h-32 bg-slate-800 rounded-full flex items-center justify-center my-8 border-4 border-slate-700 shadow-inner"
          >
            {isMining ? (
              <Pickaxe className="w-14 h-14 text-green-500" />
            ) : (
              <div className="text-6xl grayscale opacity-50">🐸</div>
            )}
          </motion.div>

          <button
            onClick={() => setIsMining(!isMining)}
            className={`w-full py-4 rounded-xl font-bold text-lg transition-all flex items-center justify-center gap-2 ${
              isMining 
                ? 'bg-red-500/10 text-red-500 border border-red-500/30 hover:bg-red-500/20' 
                : 'bg-green-500 text-slate-950 hover:bg-green-400 hover:shadow-[0_0_20px_rgba(34,197,94,0.4)]'
            }`}
          >
            {isMining ? 'Stop Mining' : 'Start Mining'}
            {isMining && <Loader2 className="w-5 h-5 animate-spin" />}
          </button>
        </div>

        {/* Withdrawal Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-blue-500/10 rounded-lg">
              <Wallet className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Withdraw PEPE</h2>
              <p className="text-xs text-slate-400">Via FaucetPay API</p>
            </div>
          </div>

          <div className="flex-1 space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Amount</label>
              <div className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-center justify-between text-slate-500">
                <span className="font-mono text-lg">{MIN_WITHDRAW} PEPE</span>
                <span className="text-xs bg-slate-800 px-2 py-1 rounded text-slate-400">Minimum</span>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">FaucetPay Email</label>
              <input
                type="email"
                placeholder="your@email.com"
                value={faucetPayEmail}
                onChange={(e) => setFaucetPayEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 outline-none focus:border-green-500 transition-colors placeholder:text-slate-700"
              />
            </div>
          </div>

          <div className="mt-6">
            {withdrawStatus === 'error' && (
              <div className="mb-4 bg-red-500/10 text-red-400 p-3 rounded-xl flex items-start gap-2 text-sm border border-red-500/20">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <p>{withdrawMessage}</p>
              </div>
            )}
            
            {withdrawStatus === 'success' && (
              <div className="mb-4 bg-green-500/10 text-green-400 p-3 rounded-xl flex items-start gap-2 text-sm border border-green-500/20">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                <p>{withdrawMessage}</p>
              </div>
            )}

            <button
              onClick={handleWithdraw}
              disabled={withdrawStatus === 'loading'}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-xl font-bold transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {withdrawStatus === 'loading' ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" /> Processing...
                </>
              ) : (
                <>
                  <Coins className="w-5 h-5" /> Withdraw to FaucetPay
                </>
              )}
            </button>
          </div>
        </div>
        </div>
      </main>

      <footer className="mt-12 text-center text-sm text-slate-500 max-w-lg">
        <p>Mining is simulated in this demo, but the FaucetPay withdrawals are connected to the live backend API.</p>
      </footer>
    </div>
  );
}
